<form action="main.php" method="POST">
    <select name="pays" id="pays">
        <option value="jap">Japon</option>
        <option value="bxl">Bruxelles</option>
    </select>
    <button type="submit">OK</button>
</form>